| Setting | Status | Exposure | Description |
|---------|--------|----------|-------------|
| NAME |   |  | DESCRIPTION EXPOSURE |
| PrivateTmp= |   |  | Service runs in special boot phase, option is not appropriate |
| ProtectHome= |   |  | Service runs in special boot phase, option is not appropriate |
| ProtectSystem= |   |  | Service runs in special boot phase, option is not appropriate |
| RootDirectory=/RootImage= |   |  | Service runs in special boot phase, option is not appropriate |
| SupplementaryGroups= |   |  | Service runs as root, option does not matter |
| RemoveIPC= |   |  | Service runs as root, option does not apply |
| User=/DynamicUser= | ✗ | 0.4 | Service runs as root user |
| CapabilityBoundingSet=~CAP_SYS_TIME | ✗ | 0.2 | Service processes may change the system clock |
| NoNewPrivileges= | ✗ | 0.2 | Service processes may acquire new privileges |
| AmbientCapabilities= | ✓ |  | Service process does not receive ambient capabilities |
| PrivateDevices= | ✗ | 0.2 | Service potentially has access to hardware devices |
| ProtectClock= | ✗ | 0.2 | Service may write to the hardware clock or system clock |
| CapabilityBoundingSet=~CAP_SYS_PACCT | ✗ | 0.1 | Service may use acct() |
| CapabilityBoundingSet=~CAP_KILL | ✗ | 0.1 | Service may send UNIX signals to arbitrary processes |
| ProtectKernelLogs= | ✗ | 0.2 | Service may read from or write to the kernel log ring buffer |
| CapabilityBoundingSet=~CAP_WAKE_ALARM | ✗ | 0.1 | Service may program timers that wake up the system |
| CapabilityBoundingSet=~CAP_(DAC_*|FOWNER|IPC_OWNER) | ✗ | 0.2 | Service may override UNIX file/IPC permission checks |
| CapabilityBoundingSet=~CAP_BPF | ✗ | 0.1 | Service may not load BPF programs |
| ProtectControlGroups= | ✗ | 0.2 | Service may modify the control group file system |
| CapabilityBoundingSet=~CAP_LINUX_IMMUTABLE | ✗ | 0.1 | Service may mark files immutable |
| CapabilityBoundingSet=~CAP_IPC_LOCK | ✗ | 0.1 | Service may lock memory into RAM |
| ProtectKernelModules= | ✗ | 0.2 | Service may load or read kernel modules |
| CapabilityBoundingSet=~CAP_SYS_MODULE | ✗ | 0.2 | Service may load kernel modules |
| CapabilityBoundingSet=~CAP_SYS_TTY_CONFIG | ✗ | 0.1 | Service may issue vhangup() |
| CapabilityBoundingSet=~CAP_SYS_BOOT | ✗ | 0.1 | Service may issue reboot() |
| CapabilityBoundingSet=~CAP_SYS_CHROOT | ✗ | 0.1 | Service may issue chroot() |
| PrivateMounts= | ✗ | 0.2 | Service may install system mounts |
| SystemCallArchitectures= | ✗ | 0.2 | Service may execute system calls with all ABIs |
| CapabilityBoundingSet=~CAP_BLOCK_SUSPEND | ✗ | 0.1 | Service may establish wake locks |
| MemoryDenyWriteExecute= | ✗ | 0.1 | Service may create writable executable memory mappings |
| RestrictNamespaces=~user | ✗ | 0.3 | Service may create user namespaces |
| RestrictNamespaces=~pid | ✗ | 0.1 | Service may create process namespaces |
| RestrictNamespaces=~net | ✗ | 0.1 | Service may create network namespaces |
| RestrictNamespaces=~uts | ✗ | 0.1 | Service may create hostname namespaces |
| RestrictNamespaces=~mnt | ✗ | 0.1 | Service may create file system namespaces |
| CapabilityBoundingSet=~CAP_LEASE | ✗ | 0.1 | Service may create file leases |
| CapabilityBoundingSet=~CAP_MKNOD | ✗ | 0.1 | Service may create device nodes |
| RestrictNamespaces=~cgroup | ✗ | 0.1 | Service may create cgroup namespaces |
| RestrictSUIDSGID= | ✗ | 0.2 | Service may create SUID/SGID files |
| RestrictNamespaces=~ipc | ✗ | 0.1 | Service may create IPC namespaces |
| ProtectHostname= | ✗ | 0.1 | Service may change system host/domainname |
| CapabilityBoundingSet=~CAP_(CHOWN|FSETID|SETFCAP) | ✗ | 0.2 | Service may change file ownership/access mode/capabilities unrestricted |
| CapabilityBoundingSet=~CAP_SET(UID|GID|PCAP) | ✗ | 0.3 | Service may change UID/GID identities/capabilities |
| LockPersonality= | ✗ | 0.1 | Service may change ABI personality |
| ProtectKernelTunables= | ✗ | 0.2 | Service may alter kernel tunables |
| RestrictAddressFamilies=~AF_PACKET | ✗ | 0.2 | Service may allocate packet sockets |
| RestrictAddressFamilies=~AF_NETLINK | ✗ | 0.1 | Service may allocate netlink sockets |
| RestrictAddressFamilies=~AF_UNIX | ✗ | 0.1 | Service may allocate local sockets |
| RestrictAddressFamilies=~… | ✗ | 0.3 | Service may allocate exotic sockets |
| RestrictAddressFamilies=~AF_(INET|INET6) | ✗ | 0.3 | Service may allocate Internet sockets |
| CapabilityBoundingSet=~CAP_MAC_* | ✗ | 0.1 | Service may adjust SMACK MAC |
| RestrictRealtime= | ✗ | 0.1 | Service may acquire realtime scheduling |
| CapabilityBoundingSet=~CAP_SYS_RAWIO | ✗ | 0.2 | Service has raw I/O access |
| CapabilityBoundingSet=~CAP_SYS_PTRACE | ✗ | 0.3 | Service has ptrace() debugging abilities |
| CapabilityBoundingSet=~CAP_SYS_(NICE|RESOURCE) | ✗ | 0.1 | Service has privileges to change resource use parameters |
| DeviceAllow= | ✗ | 0.2 | Service has no device ACL |
| CapabilityBoundingSet=~CAP_NET_ADMIN | ✗ | 0.2 | Service has network configuration privileges |
| ProtectProc= | ✗ | 0.2 | Service has full access to process tree (/proc hidepid=) |
| ProcSubset= | ✗ | 0.1 | Service has full access to non-process /proc files (/proc subset=) |
| CapabilityBoundingSet=~CAP_NET_(BIND_SERVICE|BROADCAST|RAW) | ✗ | 0.1 | Service has elevated networking privileges |
| CapabilityBoundingSet=~CAP_AUDIT_* | ✗ | 0.1 | Service has audit subsystem access |
| CapabilityBoundingSet=~CAP_SYS_ADMIN | ✗ | 0.3 | Service has administrator privileges |
| PrivateNetwork= | ✗ | 0.5 | Service has access to the host's network |
| PrivateUsers= | ✗ | 0.2 | Service has access to other users |
| CapabilityBoundingSet=~CAP_SYSLOG | ✗ | 0.1 | Service has access to kernel logging |
| KeyringMode= | ✓ |  | Service doesn't share key material with other services |
| Delegate= | ✓ |  | Service does not maintain its own delegated control group subtree |
| SystemCallFilter=~@clock | ✗ | 0.2 | Service does not filter system calls |
| SystemCallFilter=~@cpu-emulation | ✗ | 0.1 | Service does not filter system calls |
| SystemCallFilter=~@debug | ✗ | 0.2 | Service does not filter system calls |
| SystemCallFilter=~@module | ✗ | 0.2 | Service does not filter system calls |
| SystemCallFilter=~@mount | ✗ | 0.2 | Service does not filter system calls |
| SystemCallFilter=~@obsolete | ✗ | 0.1 | Service does not filter system calls |
| SystemCallFilter=~@privileged | ✗ | 0.2 | Service does not filter system calls |
| SystemCallFilter=~@raw-io | ✗ | 0.2 | Service does not filter system calls |
| SystemCallFilter=~@reboot | ✗ | 0.2 | Service does not filter system calls |
| SystemCallFilter=~@resources | ✗ | 0.2 | Service does not filter system calls |
| SystemCallFilter=~@swap | ✗ | 0.2 | Service does not filter system calls |
| IPAddressDeny= | ✗ | 0.2 | Service does not define an IP address allow list |
| NotifyAccess= | ✓ |  | Service child processes cannot alter service state |
| UMask= | ✗ | 0.1 | Files created by service are world-readable by default |
| Overall | → |  | exposure level for multipathd.service: 9.5 UNSAFE 😨 |
