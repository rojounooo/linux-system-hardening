| Setting | Status | Exposure | Description |
|---------|--------|----------|-------------|
| NAME |   |  | DESCRIPTION EXPOSURE |
| RootDirectory=/RootImage= | ✗ | 0.1 | Service runs within the host's root directory |
| SupplementaryGroups= |   |  | Service runs as root, option does not matter |
| RemoveIPC= |   |  | Service runs as root, option does not apply |
| User=/DynamicUser= | ✗ | 0.4 | Service runs as root user |
| CapabilityBoundingSet=~CAP_SYS_TIME | ✓ |  | Service processes cannot change the system clock |
| NoNewPrivileges= | ✓ |  | Service processes cannot acquire new privileges |
| AmbientCapabilities= | ✓ |  | Service process does not receive ambient capabilities |
| PrivateDevices= | ✗ | 0.2 | Service potentially has access to hardware devices |
| ProtectClock= | ✗ | 0.2 | Service may write to the hardware clock or system clock |
| ProtectKernelLogs= | ✗ | 0.2 | Service may read from or write to the kernel log ring buffer |
| ProtectControlGroups= | ✗ | 0.2 | Service may modify the control group file system |
| ProtectKernelModules= | ✗ | 0.2 | Service may load or read kernel modules |
| CapabilityBoundingSet=~CAP_BPF | ✓ |  | Service may load BPF programs |
| SystemCallArchitectures= | ✗ | 0.2 | Service may execute system calls with all ABIs |
| MemoryDenyWriteExecute= | ✗ | 0.1 | Service may create writable executable memory mappings |
| RestrictNamespaces=~user | ✗ | 0.3 | Service may create user namespaces |
| RestrictNamespaces=~pid | ✗ | 0.1 | Service may create process namespaces |
| RestrictNamespaces=~net | ✗ | 0.1 | Service may create network namespaces |
| RestrictNamespaces=~uts | ✗ | 0.1 | Service may create hostname namespaces |
| RestrictNamespaces=~mnt | ✗ | 0.1 | Service may create file system namespaces |
| RestrictNamespaces=~cgroup | ✗ | 0.1 | Service may create cgroup namespaces |
| RestrictSUIDSGID= | ✗ | 0.2 | Service may create SUID/SGID files |
| RestrictNamespaces=~ipc | ✗ | 0.1 | Service may create IPC namespaces |
| ProtectHostname= | ✗ | 0.1 | Service may change system host/domainname |
| LockPersonality= | ✗ | 0.1 | Service may change ABI personality |
| ProtectKernelTunables= | ✗ | 0.2 | Service may alter kernel tunables |
| RestrictAddressFamilies=~AF_NETLINK | ✗ | 0.1 | Service may allocate netlink sockets |
| RestrictAddressFamilies=~AF_UNIX | ✗ | 0.1 | Service may allocate local sockets |
| RestrictAddressFamilies=~… | ✗ | 0.3 | Service may allocate exotic sockets |
| RestrictRealtime= | ✗ | 0.1 | Service may acquire realtime scheduling |
| CapabilityBoundingSet=~CAP_SYS_RAWIO | ✓ |  | Service has no raw I/O access |
| CapabilityBoundingSet=~CAP_SYS_PTRACE | ✓ |  | Service has no ptrace() debugging abilities |
| CapabilityBoundingSet=~CAP_SYS_(NICE|RESOURCE) | ✓ |  | Service has no privileges to change resource use parameters |
| CapabilityBoundingSet=~CAP_NET_(BIND_SERVICE|BROADCAST|RAW) | ✓ |  | Service has no elevated networking privileges |
| DeviceAllow= | ✗ | 0.2 | Service has no device ACL |
| CapabilityBoundingSet=~CAP_AUDIT_* | ✓ |  | Service has no audit subsystem access |
| PrivateTmp= | ✓ |  | Service has no access to other software's temporary files |
| CapabilityBoundingSet=~CAP_SYSLOG | ✓ |  | Service has no access to kernel logging |
| ProtectHome= | ✓ |  | Service has no access to home directories |
| CapabilityBoundingSet=~CAP_NET_ADMIN | ✗ | 0.2 | Service has network configuration privileges |
| ProtectSystem= | ✗ | 0.1 | Service has limited write access to the OS file hierarchy |
| ProtectProc= | ✗ | 0.2 | Service has full access to process tree (/proc hidepid=) |
| ProcSubset= | ✗ | 0.1 | Service has full access to non-process /proc files (/proc subset=) |
| CapabilityBoundingSet=~CAP_SYS_ADMIN | ✗ | 0.3 | Service has administrator privileges |
| PrivateNetwork= | ✗ | 0.5 | Service has access to the host's network |
| PrivateUsers= | ✗ | 0.2 | Service has access to other users |
| KeyringMode= | ✓ |  | Service doesn't share key material with other services |
| Delegate= | ✓ |  | Service does not maintain its own delegated control group subtree |
| SystemCallFilter=~@clock | ✗ | 0.2 | Service does not filter system calls |
| SystemCallFilter=~@cpu-emulation | ✗ | 0.1 | Service does not filter system calls |
| SystemCallFilter=~@debug | ✗ | 0.2 | Service does not filter system calls |
| SystemCallFilter=~@module | ✗ | 0.2 | Service does not filter system calls |
| SystemCallFilter=~@mount | ✗ | 0.2 | Service does not filter system calls |
| SystemCallFilter=~@obsolete | ✗ | 0.1 | Service does not filter system calls |
| SystemCallFilter=~@privileged | ✗ | 0.2 | Service does not filter system calls |
| SystemCallFilter=~@raw-io | ✗ | 0.2 | Service does not filter system calls |
| SystemCallFilter=~@reboot | ✗ | 0.2 | Service does not filter system calls |
| SystemCallFilter=~@resources | ✗ | 0.2 | Service does not filter system calls |
| SystemCallFilter=~@swap | ✗ | 0.2 | Service does not filter system calls |
| IPAddressDeny= | ✗ | 0.2 | Service does not define an IP address allow list |
| NotifyAccess= | ✓ |  | Service child processes cannot alter service state |
| CapabilityBoundingSet=~CAP_SYS_PACCT | ✓ |  | Service cannot use acct() |
| CapabilityBoundingSet=~CAP_KILL | ✓ |  | Service cannot send UNIX signals to arbitrary processes |
| CapabilityBoundingSet=~CAP_WAKE_ALARM | ✓ |  | Service cannot program timers that wake up the system |
| CapabilityBoundingSet=~CAP_(DAC_*|FOWNER|IPC_OWNER) | ✓ |  | Service cannot override UNIX file/IPC permission checks |
| CapabilityBoundingSet=~CAP_LINUX_IMMUTABLE | ✓ |  | Service cannot mark files immutable |
| CapabilityBoundingSet=~CAP_IPC_LOCK | ✓ |  | Service cannot lock memory into RAM |
| CapabilityBoundingSet=~CAP_SYS_MODULE | ✓ |  | Service cannot load kernel modules |
| CapabilityBoundingSet=~CAP_SYS_TTY_CONFIG | ✓ |  | Service cannot issue vhangup() |
| CapabilityBoundingSet=~CAP_SYS_BOOT | ✓ |  | Service cannot issue reboot() |
| CapabilityBoundingSet=~CAP_SYS_CHROOT | ✓ |  | Service cannot issue chroot() |
| PrivateMounts= | ✓ |  | Service cannot install system mounts |
| CapabilityBoundingSet=~CAP_BLOCK_SUSPEND | ✓ |  | Service cannot establish wake locks |
| CapabilityBoundingSet=~CAP_LEASE | ✓ |  | Service cannot create file leases |
| CapabilityBoundingSet=~CAP_MKNOD | ✓ |  | Service cannot create device nodes |
| CapabilityBoundingSet=~CAP_(CHOWN|FSETID|SETFCAP) | ✓ |  | Service cannot change file ownership/access mode/capabilities |
| CapabilityBoundingSet=~CAP_SET(UID|GID|PCAP) | ✓ |  | Service cannot change UID/GID identities/capabilities |
| RestrictAddressFamilies=~AF_PACKET | ✓ |  | Service cannot allocate packet sockets |
| RestrictAddressFamilies=~AF_(INET|INET6) | ✓ |  | Service cannot allocate Internet sockets |
| CapabilityBoundingSet=~CAP_MAC_* | ✓ |  | Service cannot adjust SMACK MAC |
| UMask= | ✗ | 0.1 | Files created by service are world-readable by default |
| Overall | → |  | exposure level for ModemManager.service: 6.3 MEDIUM 😐 |
