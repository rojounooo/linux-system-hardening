| Setting | Status | Exposure | Description |
|---------|--------|----------|-------------|
| NAME |   |  | DESCRIPTION EXPOSURE |
| SystemCallFilter=~@swap | ✗ | 0.2 | System call deny list defined for service, and @swap is not included (e.g. swapoff is allowed) |
| SystemCallFilter=~@resources | ✗ | 0.2 | System call deny list defined for service, and @resources is not included (e.g. ioprio_set is allowed) |
| SystemCallFilter=~@reboot | ✗ | 0.2 | System call deny list defined for service, and @reboot is not included (e.g. kexec_file_load is allowed) |
| SystemCallFilter=~@raw-io | ✗ | 0.2 | System call deny list defined for service, and @raw-io is not included (e.g. ioperm is allowed) |
| SystemCallFilter=~@privileged | ✗ | 0.2 | System call deny list defined for service, and @privileged is not included (e.g. chown is allowed) |
| SystemCallFilter=~@obsolete | ✗ | 0.1 | System call deny list defined for service, and @obsolete is not included (e.g. _sysctl is allowed) |
| SystemCallFilter=~@mount | ✓ |  | System call deny list defined for service, and @mount is included |
| SystemCallFilter=~@module | ✗ | 0.2 | System call deny list defined for service, and @module is not included (e.g. delete_module is allowed) |
| SystemCallFilter=~@debug | ✗ | 0.2 | System call deny list defined for service, and @debug is not included (e.g. lookup_dcookie is allowed) |
| SystemCallFilter=~@cpu-emulation | ✗ | 0.1 | System call deny list defined for service, and @cpu-emulation is not included (e.g. modify_ldt is allowed) |
| SystemCallFilter=~@clock | ✗ | 0.2 | System call deny list defined for service, and @clock is not included (e.g. adjtimex is allowed) |
| RootDirectory=/RootImage= | ✗ | 0.1 | Service runs within the host's root directory |
| SupplementaryGroups= |   |  | Service runs as root, option does not matter |
| RemoveIPC= |   |  | Service runs as root, option does not apply |
| User=/DynamicUser= | ✗ | 0.4 | Service runs as root user |
| RestrictRealtime= | ✓ |  | Service realtime scheduling access is restricted |
| CapabilityBoundingSet=~CAP_SYS_TIME | ✗ | 0.2 | Service processes may change the system clock |
| NoNewPrivileges= | ✗ | 0.2 | Service processes may acquire new privileges |
| AmbientCapabilities= | ✓ |  | Service process does not receive ambient capabilities |
| PrivateDevices= | ✗ | 0.2 | Service potentially has access to hardware devices |
| ProtectClock= | ✗ | 0.2 | Service may write to the hardware clock or system clock |
| CapabilityBoundingSet=~CAP_SYS_PACCT | ✗ | 0.1 | Service may use acct() |
| CapabilityBoundingSet=~CAP_KILL | ✗ | 0.1 | Service may send UNIX signals to arbitrary processes |
| ProtectKernelLogs= | ✗ | 0.2 | Service may read from or write to the kernel log ring buffer |
| CapabilityBoundingSet=~CAP_WAKE_ALARM | ✗ | 0.1 | Service may program timers that wake up the system |
| CapabilityBoundingSet=~CAP_(DAC_*|FOWNER|IPC_OWNER) | ✗ | 0.2 | Service may override UNIX file/IPC permission checks |
| CapabilityBoundingSet=~CAP_BPF | ✗ | 0.1 | Service may not load BPF programs |
| CapabilityBoundingSet=~CAP_LINUX_IMMUTABLE | ✗ | 0.1 | Service may mark files immutable |
| CapabilityBoundingSet=~CAP_IPC_LOCK | ✗ | 0.1 | Service may lock memory into RAM |
| CapabilityBoundingSet=~CAP_SYS_TTY_CONFIG | ✗ | 0.1 | Service may issue vhangup() |
| CapabilityBoundingSet=~CAP_SYS_BOOT | ✗ | 0.1 | Service may issue reboot() |
| CapabilityBoundingSet=~CAP_SYS_CHROOT | ✗ | 0.1 | Service may issue chroot() |
| SystemCallArchitectures= | ✗ | 0.2 | Service may execute system calls with all ABIs |
| CapabilityBoundingSet=~CAP_BLOCK_SUSPEND | ✗ | 0.1 | Service may establish wake locks |
| MemoryDenyWriteExecute= | ✗ | 0.1 | Service may create writable executable memory mappings |
| RestrictNamespaces=~user | ✗ | 0.3 | Service may create user namespaces |
| RestrictNamespaces=~pid | ✗ | 0.1 | Service may create process namespaces |
| RestrictNamespaces=~net | ✗ | 0.1 | Service may create network namespaces |
| RestrictNamespaces=~uts | ✗ | 0.1 | Service may create hostname namespaces |
| RestrictNamespaces=~mnt | ✗ | 0.1 | Service may create file system namespaces |
| CapabilityBoundingSet=~CAP_LEASE | ✗ | 0.1 | Service may create file leases |
| CapabilityBoundingSet=~CAP_MKNOD | ✗ | 0.1 | Service may create device nodes |
| RestrictNamespaces=~cgroup | ✗ | 0.1 | Service may create cgroup namespaces |
| RestrictSUIDSGID= | ✗ | 0.2 | Service may create SUID/SGID files |
| RestrictNamespaces=~ipc | ✗ | 0.1 | Service may create IPC namespaces |
| ProtectHostname= | ✗ | 0.1 | Service may change system host/domainname |
| CapabilityBoundingSet=~CAP_(CHOWN|FSETID|SETFCAP) | ✗ | 0.2 | Service may change file ownership/access mode/capabilities unrestricted |
| CapabilityBoundingSet=~CAP_SET(UID|GID|PCAP) | ✗ | 0.3 | Service may change UID/GID identities/capabilities |
| LockPersonality= | ✗ | 0.1 | Service may change ABI personality |
| ProtectKernelTunables= | ✗ | 0.2 | Service may alter kernel tunables |
| RestrictAddressFamilies=~AF_NETLINK | ✗ | 0.1 | Service may allocate netlink sockets |
| RestrictAddressFamilies=~AF_UNIX | ✗ | 0.1 | Service may allocate local sockets |
| RestrictAddressFamilies=~AF_(INET|INET6) | ✗ | 0.3 | Service may allocate Internet sockets |
| CapabilityBoundingSet=~CAP_MAC_* | ✗ | 0.1 | Service may adjust SMACK MAC |
| ProtectSystem= | ✗ | 0.1 | Service has very limited write access to the OS file hierarchy |
| CapabilityBoundingSet=~CAP_SYS_RAWIO | ✗ | 0.2 | Service has raw I/O access |
| CapabilityBoundingSet=~CAP_SYS_PTRACE | ✗ | 0.3 | Service has ptrace() debugging abilities |
| CapabilityBoundingSet=~CAP_SYS_(NICE|RESOURCE) | ✗ | 0.1 | Service has privileges to change resource use parameters |
| DeviceAllow= | ✗ | 0.2 | Service has no device ACL |
| PrivateTmp= | ✓ |  | Service has no access to other software's temporary files |
| ProtectHome= | ✓ |  | Service has no access to home directories |
| CapabilityBoundingSet=~CAP_NET_ADMIN | ✗ | 0.2 | Service has network configuration privileges |
| ProtectProc= | ✗ | 0.2 | Service has full access to process tree (/proc hidepid=) |
| ProcSubset= | ✗ | 0.1 | Service has full access to non-process /proc files (/proc subset=) |
| CapabilityBoundingSet=~CAP_NET_(BIND_SERVICE|BROADCAST|RAW) | ✗ | 0.1 | Service has elevated networking privileges |
| CapabilityBoundingSet=~CAP_AUDIT_* | ✗ | 0.1 | Service has audit subsystem access |
| CapabilityBoundingSet=~CAP_SYS_ADMIN | ✗ | 0.3 | Service has administrator privileges |
| PrivateNetwork= | ✗ | 0.5 | Service has access to the host's network |
| PrivateUsers= | ✗ | 0.2 | Service has access to other users |
| CapabilityBoundingSet=~CAP_SYSLOG | ✗ | 0.1 | Service has access to kernel logging |
| KeyringMode= | ✓ |  | Service doesn't share key material with other services |
| Delegate= | ✓ |  | Service does not maintain its own delegated control group subtree |
| IPAddressDeny= | ✗ | 0.2 | Service does not define an IP address allow list |
| NotifyAccess= | ✓ |  | Service child processes cannot alter service state |
| ProtectControlGroups= | ✓ |  | Service cannot modify the control group file system |
| ProtectKernelModules= | ✓ |  | Service cannot load or read kernel modules |
| CapabilityBoundingSet=~CAP_SYS_MODULE | ✓ |  | Service cannot load kernel modules |
| PrivateMounts= | ✓ |  | Service cannot install system mounts |
| RestrictAddressFamilies=~AF_PACKET | ✓ |  | Service cannot allocate packet sockets |
| RestrictAddressFamilies=~… | ✓ |  | Service cannot allocate exotic sockets |
| UMask= | ✗ | 0.1 | Files created by service are world-readable by default |
| Overall | → |  | exposure level for fwupd.service: 7.7 EXPOSED 🙁 |
