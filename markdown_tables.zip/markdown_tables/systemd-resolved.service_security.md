| Setting | Status | Exposure | Description |
|---------|--------|----------|-------------|
| NAME |   |  | DESCRIPTION EXPOSURE |
| SystemCallFilter=~@swap | ✓ |  | System call allow list defined for service, and @swap is not included |
| SystemCallFilter=~@resources | ✗ | 0.2 | System call allow list defined for service, and @resources is included (e.g. ioprio_set is allowed) |
| SystemCallFilter=~@reboot | ✓ |  | System call allow list defined for service, and @reboot is not included |
| SystemCallFilter=~@raw-io | ✓ |  | System call allow list defined for service, and @raw-io is not included |
| SystemCallFilter=~@privileged | ✗ | 0.2 | System call allow list defined for service, and @privileged is included (e.g. chown is allowed) |
| SystemCallFilter=~@obsolete | ✓ |  | System call allow list defined for service, and @obsolete is not included |
| SystemCallFilter=~@mount | ✓ |  | System call allow list defined for service, and @mount is not included |
| SystemCallFilter=~@module | ✓ |  | System call allow list defined for service, and @module is not included |
| SystemCallFilter=~@debug | ✓ |  | System call allow list defined for service, and @debug is not included |
| SystemCallFilter=~@cpu-emulation | ✓ |  | System call allow list defined for service, and @cpu-emulation is not included |
| SystemCallFilter=~@clock | ✓ |  | System call allow list defined for service, and @clock is not included |
| RemoveIPC= | ✗ | 0.1 | Service user may leave SysV IPC objects around |
| User=/DynamicUser= | ✓ |  | Service runs under a static non-root user identity |
| PrivateTmp= |   |  | Service runs in special boot phase, option is not appropriate |
| ProtectHome= |   |  | Service runs in special boot phase, option is not appropriate |
| ProtectSystem= |   |  | Service runs in special boot phase, option is not appropriate |
| RootDirectory=/RootImage= |   |  | Service runs in special boot phase, option is not appropriate |
| RestrictRealtime= | ✓ |  | Service realtime scheduling access is restricted |
| CapabilityBoundingSet=~CAP_SYS_TIME | ✓ |  | Service processes cannot change the system clock |
| NoNewPrivileges= | ✓ |  | Service processes cannot acquire new privileges |
| AmbientCapabilities= | ✗ | 0.1 | Service process receives ambient capabilities |
| CapabilityBoundingSet=~CAP_BPF | ✓ |  | Service may load BPF programs |
| SystemCallArchitectures= | ✓ |  | Service may execute system calls only with native ABI |
| ProtectHostname= | ✗ | 0.1 | Service may change system host/domainname |
| CapabilityBoundingSet=~CAP_SET(UID|GID|PCAP) | ✗ | 0.3 | Service may change UID/GID identities/capabilities |
| RestrictAddressFamilies=~AF_NETLINK | ✗ | 0.1 | Service may allocate netlink sockets |
| RestrictAddressFamilies=~AF_UNIX | ✗ | 0.1 | Service may allocate local sockets |
| RestrictAddressFamilies=~AF_(INET|INET6) | ✗ | 0.3 | Service may allocate Internet sockets |
| SupplementaryGroups= | ✓ |  | Service has no supplementary groups |
| CapabilityBoundingSet=~CAP_SYS_RAWIO | ✓ |  | Service has no raw I/O access |
| CapabilityBoundingSet=~CAP_SYS_PTRACE | ✓ |  | Service has no ptrace() debugging abilities |
| CapabilityBoundingSet=~CAP_SYS_(NICE|RESOURCE) | ✓ |  | Service has no privileges to change resource use parameters |
| CapabilityBoundingSet=~CAP_NET_ADMIN | ✓ |  | Service has no network configuration privileges |
| CapabilityBoundingSet=~CAP_AUDIT_* | ✓ |  | Service has no audit subsystem access |
| CapabilityBoundingSet=~CAP_SYS_ADMIN | ✓ |  | Service has no administrator privileges |
| CapabilityBoundingSet=~CAP_SYSLOG | ✓ |  | Service has no access to kernel logging |
| PrivateDevices= | ✓ |  | Service has no access to hardware devices |
| ProtectProc= | ✗ | 0.2 | Service has full access to process tree (/proc hidepid=) |
| ProcSubset= | ✗ | 0.1 | Service has full access to non-process /proc files (/proc subset=) |
| CapabilityBoundingSet=~CAP_NET_(BIND_SERVICE|BROADCAST|RAW) | ✗ | 0.1 | Service has elevated networking privileges |
| PrivateNetwork= | ✗ | 0.5 | Service has access to the host's network |
| PrivateUsers= | ✗ | 0.2 | Service has access to other users |
| DeviceAllow= | ✗ | 0.1 | Service has a device ACL with some special devices: char-rtc:r |
| KeyringMode= | ✓ |  | Service doesn't share key material with other services |
| Delegate= | ✓ |  | Service does not maintain its own delegated control group subtree |
| IPAddressDeny= | ✗ | 0.2 | Service does not define an IP address allow list |
| NotifyAccess= | ✓ |  | Service child processes cannot alter service state |
| ProtectClock= | ✓ |  | Service cannot write to the hardware clock or system clock |
| CapabilityBoundingSet=~CAP_SYS_PACCT | ✓ |  | Service cannot use acct() |
| CapabilityBoundingSet=~CAP_KILL | ✓ |  | Service cannot send UNIX signals to arbitrary processes |
| ProtectKernelLogs= | ✓ |  | Service cannot read from or write to the kernel log ring buffer |
| CapabilityBoundingSet=~CAP_WAKE_ALARM | ✓ |  | Service cannot program timers that wake up the system |
| CapabilityBoundingSet=~CAP_(DAC_*|FOWNER|IPC_OWNER) | ✓ |  | Service cannot override UNIX file/IPC permission checks |
| ProtectControlGroups= | ✓ |  | Service cannot modify the control group file system |
| CapabilityBoundingSet=~CAP_LINUX_IMMUTABLE | ✓ |  | Service cannot mark files immutable |
| CapabilityBoundingSet=~CAP_IPC_LOCK | ✓ |  | Service cannot lock memory into RAM |
| ProtectKernelModules= | ✓ |  | Service cannot load or read kernel modules |
| CapabilityBoundingSet=~CAP_SYS_MODULE | ✓ |  | Service cannot load kernel modules |
| CapabilityBoundingSet=~CAP_SYS_TTY_CONFIG | ✓ |  | Service cannot issue vhangup() |
| CapabilityBoundingSet=~CAP_SYS_BOOT | ✓ |  | Service cannot issue reboot() |
| CapabilityBoundingSet=~CAP_SYS_CHROOT | ✓ |  | Service cannot issue chroot() |
| PrivateMounts= | ✓ |  | Service cannot install system mounts |
| CapabilityBoundingSet=~CAP_BLOCK_SUSPEND | ✓ |  | Service cannot establish wake locks |
| MemoryDenyWriteExecute= | ✓ |  | Service cannot create writable executable memory mappings |
| RestrictNamespaces=~user | ✓ |  | Service cannot create user namespaces |
| RestrictNamespaces=~pid | ✓ |  | Service cannot create process namespaces |
| RestrictNamespaces=~net | ✓ |  | Service cannot create network namespaces |
| RestrictNamespaces=~uts | ✓ |  | Service cannot create hostname namespaces |
| RestrictNamespaces=~mnt | ✓ |  | Service cannot create file system namespaces |
| CapabilityBoundingSet=~CAP_LEASE | ✓ |  | Service cannot create file leases |
| CapabilityBoundingSet=~CAP_MKNOD | ✓ |  | Service cannot create device nodes |
| RestrictNamespaces=~cgroup | ✓ |  | Service cannot create cgroup namespaces |
| RestrictNamespaces=~ipc | ✓ |  | Service cannot create IPC namespaces |
| CapabilityBoundingSet=~CAP_(CHOWN|FSETID|SETFCAP) | ✓ |  | Service cannot change file ownership/access mode/capabilities |
| LockPersonality= | ✓ |  | Service cannot change ABI personality |
| ProtectKernelTunables= | ✓ |  | Service cannot alter kernel tunables (/proc/sys, …) |
| RestrictAddressFamilies=~AF_PACKET | ✓ |  | Service cannot allocate packet sockets |
| RestrictAddressFamilies=~… | ✓ |  | Service cannot allocate exotic sockets |
| CapabilityBoundingSet=~CAP_MAC_* | ✓ |  | Service cannot adjust SMACK MAC |
| RestrictSUIDSGID= | ✓ |  | SUID/SGID file creation by service is restricted |
| UMask= | ✗ | 0.1 | Files created by service are world-readable by default |
| Overall | → |  | exposure level for systemd-resolved.service: 2.2 OK 🙂 |
