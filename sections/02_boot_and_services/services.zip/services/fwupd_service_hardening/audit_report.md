# [Service Name] Audit Report

_Include results from security tools (e.g., Lynis, systemd-analyze, nmap) before and after hardening._
